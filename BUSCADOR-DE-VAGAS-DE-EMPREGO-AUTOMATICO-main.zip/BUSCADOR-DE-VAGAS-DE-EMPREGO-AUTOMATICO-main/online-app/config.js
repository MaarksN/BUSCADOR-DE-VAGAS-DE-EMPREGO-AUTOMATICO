// Edite esta URL após fazer o deploy do Worker.
const CONFIG = {
  WORKER_URL: 'https://buscador-vagas-worker.SEU_SUBDOMINIO.workers.dev'
  // WORKER_URL: 'http://localhost:8787'
};

export default CONFIG;
