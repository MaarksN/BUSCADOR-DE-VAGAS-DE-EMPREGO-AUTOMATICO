export async function searchPlaceholder() {
  return [];
}
